﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TpPav.Entities
{
    public class Permiso
    {
        public Perfil Perfil { get; set; }
        public Formulario Formulario { get; set; }
                
    }
}
